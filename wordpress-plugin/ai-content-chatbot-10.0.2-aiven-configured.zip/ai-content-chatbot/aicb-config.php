<?php

if (!defined('ABSPATH')) {
    exit;
}

define('AICB_DB_HOST', 'mysql-171fcc14-florianmatthias-c01c.a.aivencloud.com');
define('AICB_DB_PORT', 16916);
define('AICB_DB_NAME', 'defaultdb');
define('AICB_DB_USER', 'avnadmin');
define('AICB_DB_PASSWORD', 'AVNS_B2SMMGR0CSJT32XawCr');
define('AICB_DB_PREFIX', '');
