<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Small wpdb-compatible adapter for the plugin's dedicated MySQL database.
 *
 * The plugin intentionally does not reuse WordPress' global $wpdb connection:
 * all AICB-owned records live in the separately configured Aiven database.
 */
final class AICB_External_DB {
    public string $prefix;
    public int $insert_id = 0;
    public string $last_error = '';

    private PDO $pdo;
    private bool $suppress_errors = false;

    public function __construct(array $config) {
        if (!extension_loaded('pdo_mysql')) {
            throw new RuntimeException('AICB benoetigt die PHP-Erweiterung pdo_mysql.');
        }

        $host = trim((string) ($config['host'] ?? ''));
        $port = (int) ($config['port'] ?? 3306);
        $name = trim((string) ($config['name'] ?? ''));
        $user = (string) ($config['user'] ?? '');
        $password = (string) ($config['password'] ?? '');
        $ssl_ca = trim((string) ($config['ssl_ca'] ?? ''));

        if ($host === '' || $name === '' || $user === '' || $password === '') {
            throw new RuntimeException('AICB-Datenbankkonfiguration ist unvollstaendig.');
        }
        if ($ssl_ca === '' || !is_readable($ssl_ca)) {
            throw new RuntimeException('AICB_DB_SSL_CA fehlt oder ist nicht lesbar.');
        }

        $raw_prefix = (string) ($config['prefix'] ?? '');
        if ($raw_prefix !== '' && !preg_match('/^[A-Za-z0-9_]+$/', $raw_prefix)) {
            throw new RuntimeException('AICB_DB_PREFIX darf nur Buchstaben, Zahlen und Unterstriche enthalten.');
        }
        $this->prefix = $raw_prefix;

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            $host,
            $port > 0 ? $port : 3306,
            $name
        );
        $ssl_ca_attribute = class_exists('Pdo\\Mysql')
            ? constant('Pdo\\Mysql::ATTR_SSL_CA')
            : constant('PDO::MYSQL_ATTR_SSL_CA');
        $verify_attribute = class_exists('Pdo\\Mysql') && defined('Pdo\\Mysql::ATTR_SSL_VERIFY_SERVER_CERT')
            ? constant('Pdo\\Mysql::ATTR_SSL_VERIFY_SERVER_CERT')
            : (defined('PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT') ? constant('PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT') : null);
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 8,
            $ssl_ca_attribute => $ssl_ca,
        ];
        if ($verify_attribute !== null) {
            $options[$verify_attribute] = true;
        }

        try {
            $this->pdo = new PDO($dsn, $user, $password, $options);
        } catch (PDOException $e) {
            throw new RuntimeException('Verbindung zur AICB-Datenbank fehlgeschlagen: ' . $e->getMessage(), 0, $e);
        }
    }

    public function get_charset_collate(): string {
        return 'DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';
    }

    public function suppress_errors(?bool $suppress = null): bool {
        $previous = $this->suppress_errors;
        if ($suppress !== null) {
            $this->suppress_errors = $suppress;
        }
        return $previous;
    }

    public function esc_like(string $text): string {
        return addcslashes($text, '_%\\');
    }

    public function prepare(string $query, mixed ...$args): string {
        if (count($args) === 1 && is_array($args[0])) {
            $args = $args[0];
        }
        $index = 0;
        $prepared = preg_replace_callback('/%%|%[dfs]/', function (array $match) use (&$args, &$index): string {
            if ($match[0] === '%%') {
                return '%';
            }
            if (!array_key_exists($index, $args)) {
                throw new InvalidArgumentException('Zu wenige Werte fuer AICB_External_DB::prepare().');
            }
            $value = $args[$index++];
            return match ($match[0]) {
                '%d' => (string) (int) $value,
                '%f' => (string) (float) $value,
                default => $this->pdo->quote((string) $value),
            };
        }, $query);
        if ($prepared === null || $index !== count($args)) {
            throw new InvalidArgumentException('Ungueltige Platzhalter in AICB_External_DB::prepare().');
        }
        return $prepared;
    }

    public function query(string $query): int|false {
        try {
            $this->last_error = '';
            $result = $this->pdo->exec($query);
            return $result === false ? false : $result;
        } catch (PDOException $e) {
            return $this->handle_error($e);
        }
    }

    public function get_var(string $query, int $column = 0, int $row = 0): mixed {
        try {
            $this->last_error = '';
            $statement = $this->pdo->query($query);
            $rows = $statement->fetchAll(PDO::FETCH_NUM);
            return $rows[$row][$column] ?? null;
        } catch (PDOException $e) {
            $this->handle_error($e);
            return null;
        }
    }

    public function get_row(string $query, string $output = OBJECT, int $row = 0): array|object|null {
        $rows = $this->get_results($query, $output);
        return $rows[$row] ?? null;
    }

    public function get_results(string $query, string $output = OBJECT): array {
        try {
            $this->last_error = '';
            $statement = $this->pdo->query($query);
            if ($output === ARRAY_A) {
                return $statement->fetchAll(PDO::FETCH_ASSOC);
            }
            if ($output === ARRAY_N) {
                return $statement->fetchAll(PDO::FETCH_NUM);
            }
            return $statement->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            $this->handle_error($e);
            return [];
        }
    }

    public function insert(string $table, array $data, ?array $format = null): int|false {
        if (!$data) {
            return false;
        }
        $columns = array_keys($data);
        $sql = 'INSERT INTO ' . $this->quote_identifier($table)
            . ' (' . implode(', ', array_map([$this, 'quote_identifier'], $columns)) . ')'
            . ' VALUES (' . implode(', ', array_fill(0, count($columns), '?')) . ')';
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute(array_values($data));
            $this->insert_id = (int) $this->pdo->lastInsertId();
            $this->last_error = '';
            return $statement->rowCount();
        } catch (PDOException $e) {
            return $this->handle_error($e);
        }
    }

    public function update(string $table, array $data, array $where, ?array $format = null, ?array $where_format = null): int|false {
        if (!$data || !$where) {
            return false;
        }
        $set = implode(', ', array_map(fn(string $key): string => $this->quote_identifier($key) . ' = ?', array_keys($data)));
        $conditions = implode(' AND ', array_map(fn(string $key): string => $this->quote_identifier($key) . ' = ?', array_keys($where)));
        $sql = 'UPDATE ' . $this->quote_identifier($table) . " SET {$set} WHERE {$conditions}";
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute(array_merge(array_values($data), array_values($where)));
            $this->last_error = '';
            return $statement->rowCount();
        } catch (PDOException $e) {
            return $this->handle_error($e);
        }
    }

    public function delete(string $table, array $where, ?array $where_format = null): int|false {
        if (!$where) {
            return false;
        }
        $conditions = implode(' AND ', array_map(fn(string $key): string => $this->quote_identifier($key) . ' = ?', array_keys($where)));
        $sql = 'DELETE FROM ' . $this->quote_identifier($table) . " WHERE {$conditions}";
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute(array_values($where));
            $this->last_error = '';
            return $statement->rowCount();
        } catch (PDOException $e) {
            return $this->handle_error($e);
        }
    }

    public function replace(string $table, array $data): int|false {
        if (!$data) {
            return false;
        }
        $columns = array_keys($data);
        $sql = 'REPLACE INTO ' . $this->quote_identifier($table)
            . ' (' . implode(', ', array_map([$this, 'quote_identifier'], $columns)) . ')'
            . ' VALUES (' . implode(', ', array_fill(0, count($columns), '?')) . ')';
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute(array_values($data));
            $this->insert_id = (int) $this->pdo->lastInsertId();
            $this->last_error = '';
            return $statement->rowCount();
        } catch (PDOException $e) {
            return $this->handle_error($e);
        }
    }

    private function quote_identifier(string $identifier): string {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $identifier)) {
            throw new InvalidArgumentException('Ungueltiger SQL-Bezeichner.');
        }
        return '`' . $identifier . '`';
    }

    private function handle_error(PDOException $e): bool {
        $this->last_error = $e->getMessage();
        if (!$this->suppress_errors) {
            throw new RuntimeException('AICB-Datenbankfehler: ' . $e->getMessage(), 0, $e);
        }
        return false;
    }
}
